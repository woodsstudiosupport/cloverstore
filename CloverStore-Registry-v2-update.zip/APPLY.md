# Clover Store registry upgrade — prepared, not pushed

GitHub rejected tree upload and branch creation with HTTP 403: Resource not accessible by integration. Nothing was published or merged.

Target: https://github.com/woodsstudio/clover-store-registry
Base commit: 8116a9a02161a3ff9bd058e1aa158fcee9aa96ea

Contains 31 changed/new files, plus a Git patch. Existing reviews and historical apps/ files are omitted intentionally and must remain in your clone. The existing 17 published apps retain every original field and gain developerId. Five developer profiles and four category collections are added. Missing banners/details remain null. Release/announcement arrays start empty.

## Apply with Git

From a clean clone based on the above commit (or compatible main):

```sh
git switch -c clover/developer-catalogue-v2
git apply --check /path/to/CloverStore-Registry-v2.patch
git apply /path/to/CloverStore-Registry-v2.patch
python -m pip install -r requirements.txt
python scripts/validate_catalogue.py
python -m unittest discover -s tests -v
git add .
git commit -m "Add developer profiles and validated catalogue metadata"
git push -u origin clover/developer-catalogue-v2
```

Then open a pull request to main. If patch checking fails, reconcile with current data rather than overwriting live changes. Alternatively copy the files/ contents into a new branch of a cloned repository, review the diff, validate, commit and push using GitHub Desktop.

The publisher now requires a write/maintain/admin collaborator to add approved to an app/review/developer submission issue. Titles alone no longer publish. GitHub Actions permissions and branch protection can affect publishing. This is a catalogue/backend foundation; it does not add developer pages to the Android AAB or deploy a developer website.

Validation and 25 local tests passed. Existing published app fields were compared to the fetched original; review content was compared and excluded from the patch. CI could not run because GitHub write access was denied.
