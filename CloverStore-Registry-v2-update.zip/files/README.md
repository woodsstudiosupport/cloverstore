# Clover Store Registry

Clover Store Save — apps.woodsstudio.dev

Public catalogue data for Clover Store, its Android app, and the future developer publishing portal. Version 2 adds stable developer profiles without changing the legacy `registry.json` array or the `reviews.json` app-ID keyed object.

## Public data

| File | Purpose |
| --- | --- |
| `catalogue.json` | Schema version, relative endpoint paths, 30-second refresh interval, installation policy and service availability. |
| `registry.json` | Published app listings. Existing fields are preserved; named listings now include `developerId`. |
| `developers.json` | Stable developer IDs, names, optional icon/banner and public links, explicit verification state. |
| `reviews.json` | Existing published reviews. The migration leaves this file untouched. |
| `collections.json` | Initial collections derived from the current categories, linking published app IDs. |
| `releases.json` | Optional platform/channel release metadata; initially empty rather than inventing versions or hashes. |
| `announcements.json` | Optional developer/app announcements; initially empty. |
| `apps/` | Historical per-app records and new approved submissions. Some historical copies differ from published data; do not rebuild `registry.json` from this directory. |
| `compatibility.json` | Exact historical schema exceptions and a legacy review group retained for compatibility. |

Five profiles are seeded from the existing published developer labels. Missing profile artwork/links are `null`; clients should use a generic fallback. No developer receives an unearned verified badge. Developer cards/pages derive their app list and count from `registry.json` using `developerId`.

## Validate locally

Use Python 3.12:

```sh
python -m pip install -r requirements.txt
python scripts/validate_catalogue.py
python -m unittest discover -s tests -v
```

CI runs the same validation and tests on pull requests and pushes to `main`. Validation does not download APKs, inspect their actual signatures, prove publisher identity, or scan for malware.

## Publish a submission

Create an issue with exactly one type: `[App Submission]`, `[Review Submission]`, or `[Developer Submission]` in its title (or the matching `app-submission`, `review-submission`, or `developer-submission` label). Include one fenced `json` object. Examples are in [`examples/`](examples/).

A maintainer with repository write/maintain/admin permission reviews the contents and applies the `approved` label. The workflow validates the payload and all resulting catalogue relationships before committing. It comments and closes the issue only after a successful push. Rejected submissions stay open for correction; remove and reapply `approved` after editing to retry. Review issue retries do not create duplicates.

**Behaviour change:** an issue title alone no longer automatically publishes data. Register the developer profile before publishing their apps. Existing forms without `developerId` can resolve an exact registered developer name/alias; new integrations should always send the stable ID. Published names are stamped from the profile, so an arbitrary submitted developer name cannot enable the Woods Studio exception in older clients.

The Actions workflow uses its repository-scoped `GITHUB_TOKEN`, not a token embedded in an Android app or public website. Maintainer approval remains necessary; this is not an authenticated self-service developer console. GitHub Actions concurrency serializes active publications but does not provide a durable submission queue. If a queued run is cancelled, or a push conflicts with another writer, leave the issue open and retry approval after checking current data.

See [data format](docs/data-format.md), [publishing portal design](docs/developer-portal.md), [compatibility notes](docs/compatibility.md), and the [feature roadmap](docs/feature-roadmap.md).
